#!/system/bin/sh

[ -f "$MODPATH/common/install.sh" ] && . "$MODPATH"/common/install.sh
[ -d "$MODPATH/common" ] && rm -rf "$MODPATH"/common/*.sh

for file in $(find "$MODPATH" -type f -name "*.sh" -o -name "*.prop" -o -name "*.rule"); do
  [ -f "$file" ] && {
    sed -i -e "/^[[:blank:]]*#/d" -e "/^ *$/d" "$file"
    [ "$(tail -1 "$file")" ] && echo "" >>"$file"
  }
done

find "$MODPATH" -empty -type d -delete
[ -e /data/system/package_cache ] && rm -rf /data/system/package_cache/*

ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "✨ Установка завершена успешно!"
ui_print "   - Наслаждайтесь новой анимацией)"
ui_print "📱 Автор: Rooni"
ui_print "🔗 Telegram: @YouRooni"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
