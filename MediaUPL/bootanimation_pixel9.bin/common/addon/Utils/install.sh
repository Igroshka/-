#!/system/bin/sh

export_location() {
    export "$1_location"="$MODPATH$2"
}

has_command() {
    [ "$1" ] || abort "❌ Укажите имя команды в has_command()"
    [ -z "$(command -v "$1")" ] && return 1 || return 0
}

has_package() {
    [ "$1" ] || abort "❌ Укажите имя пакета в has_package()"
    [ -z "$(pm path "$1")" ] && return 1 || return 0
}

install_package() {
    [ "$1" ] || abort "❌ Укажите имя пакета в install_package()"
    [ "$2" ] || abort "❌ Укажите путь к файлу установки в install_package()"

    running_users=$(pm list users | grep running)
    running_uname=$(echo "$running_users" | head -n 1 | cut -d: -f2)
    cuid=$(am get-current-user)

    [ -z "$running_users" ] && abort "❌ Не найдено активных пользователей системы (install_package)"

    if has_package "$1"; then
        ui_print "⚠️ Пакет уже установлен: $1"
        ui_print "🔄 Выполняется удаление..."
        pm uninstall --user "$cuid" "$1"
    fi

    ui_print "📦 Установка пакета $1 для пользователя $cuid ($running_uname)..."
    chmod 0777 "$2"
    pm install --user "$cuid" "$2"
    rm -rf "$2"
}

grep_prop() {
    REGEX="s/^$1=//p"
    shift
    FILES=$*
    [ -z "$FILES" ] && FILES='/system/build.prop'
    cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

download_size() {
    [ "$1" ] && url=$1 || url="https://example.com"
    [ "$2" ] || abort "❌ Укажите имя переменной для возврата результата в download_size()"
    log_path="$TMPDIR/$(xxd -l 5 -c 5 -p </dev/random).log"

    wget --spider --server-response --output-file="$log_path" "$url"

    if [ -f "$log_path" ]; then
        eval "$2='$(
            grep -e "Length" "$log_path" |
            awk '{sum+=$2} END {printf(\"%.1f\", sum / 1024 / 1024)}'
        ) Mb'"
        rm "$log_path"
    else
        abort "❌ Не удалось определить размер содержимого по ссылке: $url"
    fi
}
