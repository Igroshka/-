#!/system/bin/sh

if [ -f "$BootAnimation_location" ]; then
    ui_print "✨ Анимация загрузки установлена!"
    ui_print ""
else
    ui_print "❌ Не найдены необходимые ресурсы!"
    touch "$MODPATH"/remove
    ui_print "⚠️ Модуль будет удалён при следующей загрузке"
fi

